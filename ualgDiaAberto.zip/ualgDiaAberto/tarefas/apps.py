from django.apps import AppConfig


class TarefasConfig(AppConfig):
    name = 'tarefas'
