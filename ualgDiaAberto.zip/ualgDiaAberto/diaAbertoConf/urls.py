from django.urls import path

from . import views


app_name =  'diaAbertoConf'
urlpatterns = [
    #path('', views.index, name='index'),
]