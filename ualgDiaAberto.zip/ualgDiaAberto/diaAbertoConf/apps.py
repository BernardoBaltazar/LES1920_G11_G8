from django.apps import AppConfig


class DiaabertoconfConfig(AppConfig):
    name = 'diaAbertoConf'
